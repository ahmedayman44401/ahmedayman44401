import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Trash2, 
  ShoppingCart, 
  User, 
  Search, 
  CheckCircle, 
  Printer, 
  FileText,
  AlertTriangle,
  ArrowRight,
  UserCheck,
  Tag,
  ExternalLink,
  Copy,
  Check,
  X as XIcon,
  Download
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { Product, Sale, SaleItem, Customer, CompanySettings } from '../types';

interface SalesManagerProps {
  products: Product[];
  sales: Sale[];
  customers?: Customer[];
  companySettings?: CompanySettings;
  onAddSale: (sale: Sale) => void;
  onRefundSale: (id: string) => void;
}

export default function SalesManager({ 
  products, 
  sales, 
  customers = [],
  companySettings = {
    companyName: 'الشركة الوطنية للمبيعات والتوريدات',
    mainWarehouse: 'فرع القاهرة والمحافظات',
    localBranch: 'نقطة بيع البيع السريع',
    commercialRegister: '١٠٢٩٣٨',
    taxNumber: '٤٥٦-٧٨٩-٠١٢',
    phone: '٠١٠٢٢٣٣٤٤٥٥',
    email: 'support@smartpos.com'
  },
  onAddSale, 
  onRefundSale 
}: SalesManagerProps) {
  // Navigation inside tab: 'pos' or 'history'
  const [salesSubTab, setSalesSubTab] = useState<'pos' | 'history'>('pos');

  // POS State
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('');
  const [typedProductCode, setTypedProductCode] = useState('');
  const [selectedQuantity, setSelectedQuantity] = useState('1');
  const [cartItems, setCartItems] = useState<SaleItem[]>([]);
  const [discountAmount, setDiscountAmount] = useState('0'); // Discount in EGP
  const [paidAmount, setPaidAmount] = useState('');
  const [notes, setNotes] = useState('');
  
  // Receipt view states
  const [activeReceipt, setActiveReceipt] = useState<Sale | null>(null);
  const [saleToRefund, setSaleToRefund] = useState<Sale | null>(null);

  // Search in History
  const [historySearch, setHistorySearch] = useState('');

  // Sandbox / Iframe print handling
  const [showIframePrintModal, setShowIframePrintModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isExportingPDF, setIsExportingPDF] = useState(false);

  // POS Validation & calculations
  const currentProduct = products.find(p => p.id === selectedProductId);
  
  const handleAddToInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId) return;
    
    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;

    const qty = parseInt(selectedQuantity);
    if (isNaN(qty) || qty <= 0) return;

    // Check if item already exists in cart, accumulate quantity
    const existingItemIdx = cartItems.findIndex(item => item.productId === product.id);
    const existingQty = existingItemIdx !== -1 ? cartItems[existingItemIdx].quantity : 0;
    const targetQty = existingQty + qty;

    if (targetQty > product.stock) {
      alert(`الكمية المطلوبة (${targetQty}) تتجاوز المخزون المتوفر (${product.stock}) لهذا المنتج!`);
      return;
    }

    const buyPrice = product.buyPrice;
    const sellPrice = product.sellPrice;
    const total = sellPrice * qty;
    const profit = (sellPrice - buyPrice) * qty;

    if (existingItemIdx !== -1) {
      // Update existing item
      const updatedCart = [...cartItems];
      const prevQty = updatedCart[existingItemIdx].quantity;
      const newQty = prevQty + qty;
      updatedCart[existingItemIdx] = {
        ...updatedCart[existingItemIdx],
        quantity: newQty,
        total: sellPrice * newQty,
        profit: (sellPrice - buyPrice) * newQty
      };
      setCartItems(updatedCart);
    } else {
      // Add new item
      const newItem: SaleItem = {
        productId: product.id,
        productName: product.name,
        quantity: qty,
        buyPrice,
        sellPrice,
        total,
        profit
      };
      setCartItems([...cartItems, newItem]);
    }

    // Reset inputs
    setSelectedProductId('');
    setTypedProductCode('');
    setSelectedQuantity('1');
  };

  const handleRemoveFromCart = (productId: string) => {
    setCartItems(cartItems.filter(item => item.productId !== productId));
  };

  const subTotal = cartItems.reduce((sum, item) => sum + item.total, 0);
  const discount = parseFloat(discountAmount) || 0;
  const grandTotal = Math.max(0, subTotal - discount);
  const finalPaidAmount = paidAmount === '' ? grandTotal : parseFloat(paidAmount) || 0;
  const remainingAmount = Math.max(0, grandTotal - finalPaidAmount);
  
  // Profit calculations
  const totalCartProfit = cartItems.reduce((sum, item) => sum + item.profit, 0) - discount;

  const handleCheckout = () => {
    if (cartItems.length === 0) return alert('سلة الفاتورة فارغة!');
    
    const invoiceId = `INV-${Date.now().toString().slice(-6)}`;
    const selectedCustomer = customers.find(c => c.id === selectedCustomerId);
    const finalCustomerName = selectedCustomer ? selectedCustomer.name : (customerName.trim() || 'عميل عام');
    const finalCustomerCode = selectedCustomer ? selectedCustomer.id : undefined;
    const finalCustomerAddress = selectedCustomer ? selectedCustomer.address : undefined;

    const newSale: Sale = {
      id: invoiceId,
      date: new Date().toISOString(),
      customerName: finalCustomerName,
      customerCode: finalCustomerCode,
      customerAddress: finalCustomerAddress,
      items: cartItems,
      totalAmount: grandTotal,
      paidAmount: finalPaidAmount,
      remainingAmount,
      totalProfit: Math.max(0, totalCartProfit),
      notes: notes.trim()
    };

    onAddSale(newSale);
    setActiveReceipt(newSale); // Show print receipt modal

    // Reset Form
    setCartItems([]);
    setCustomerName('');
    setSelectedCustomerId('');
    setDiscountAmount('0');
    setPaidAmount('');
    setNotes('');
  };

  // Filter history
  const filteredSales = sales.filter(s => {
    return s.id.toLowerCase().includes(historySearch.toLowerCase()) ||
           s.customerName.toLowerCase().includes(historySearch.toLowerCase()) ||
           (s.notes && s.notes.toLowerCase().includes(historySearch.toLowerCase()));
  });

  const replaceOklchAndOklabWithRgb = (str: string): string => {
    if (typeof str !== 'string') return str;
    let result = str;

    // 1. Match and convert oklch
    if (result.includes('oklch')) {
      result = result.replace(/oklch\s*\(\s*([\d.%+-]+)\s+([\d.+-]+)\s+([\d.+-]+)(?:\s*[\/\s,]\s*([\d.%+-]+))?\s*\)/gi, (match, p1, p2, p3, p4) => {
        const L = p1.endsWith('%') ? parseFloat(p1) / 100 : parseFloat(p1);
        const C = parseFloat(p2);
        const H = parseFloat(p3);
        
        let A = 1;
        if (p4 !== undefined) {
          A = p4.endsWith('%') ? parseFloat(p4) / 100 : parseFloat(p4);
        }

        // Convert OKLCH to OKLAB
        const theta = (H * Math.PI) / 180;
        const a = C * Math.cos(theta);
        const b = C * Math.sin(theta);

        // OKLab to LMS
        const l = L + 0.3963377774 * a + 0.2158037573 * b;
        const m = L - 0.1055613458 * a - 0.0638541728 * b;
        const s = L - 0.0894841775 * a - 1.2914855480 * b;

        // Cube LMS
        const l_ = l * l * l;
        const m_ = m * m * m;
        const s_ = s * s * s;

        // LMS to linear sRGB
        const r_lin = 4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_;
        const g_lin = -1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_;
        const b_lin = -0.0041960863 * l_ - 0.7034186147 * m_ + 1.7076147010 * s_;

        // linear sRGB to sRGB
        const toSRGB = (c: number) => {
          return c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
        };

        const out_r = Math.max(0, Math.min(255, Math.round(toSRGB(r_lin) * 255)));
        const out_g = Math.max(0, Math.min(255, Math.round(toSRGB(g_lin) * 255)));
        const out_b = Math.max(0, Math.min(255, Math.round(toSRGB(b_lin) * 255)));

        return A === 1 ? `rgb(${out_r}, ${out_g}, ${out_b})` : `rgba(${out_r}, ${out_g}, ${out_b}, ${A})`;
      });
    }

    // 2. Match and convert oklab
    if (result.includes('oklab')) {
      result = result.replace(/oklab\s*\(\s*([\d.%+-]+)\s+([\d.+-]+)\s+([\d.+-]+)(?:\s*[\/\s,]\s*([\d.%+-]+))?\s*\)/gi, (match, p1, p2, p3, p4) => {
        const L = p1.endsWith('%') ? parseFloat(p1) / 100 : parseFloat(p1);
        const a = parseFloat(p2);
        const b = parseFloat(p3);
        
        let A = 1;
        if (p4 !== undefined) {
          A = p4.endsWith('%') ? parseFloat(p4) / 100 : parseFloat(p4);
        }

        // OKLab to LMS
        const l = L + 0.3963377774 * a + 0.2158037573 * b;
        const m = L - 0.1055613458 * a - 0.0638541728 * b;
        const s = L - 0.0894841775 * a - 1.2914855480 * b;

        // Cube LMS
        const l_ = l * l * l;
        const m_ = m * m * m;
        const s_ = s * s * s;

        // LMS to linear sRGB
        const r_lin = 4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_;
        const g_lin = -1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_;
        const b_lin = -0.0041960863 * l_ - 0.7034186147 * m_ + 1.7076147010 * s_;

        // linear sRGB to sRGB
        const toSRGB = (c: number) => {
          return c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
        };

        const out_r = Math.max(0, Math.min(255, Math.round(toSRGB(r_lin) * 255)));
        const out_g = Math.max(0, Math.min(255, Math.round(toSRGB(g_lin) * 255)));
        const out_b = Math.max(0, Math.min(255, Math.round(toSRGB(b_lin) * 255)));

        return A === 1 ? `rgb(${out_r}, ${out_g}, ${out_b})` : `rgba(${out_r}, ${out_g}, ${out_b}, ${A})`;
      });
    }

    return result;
  };

  const handleExportPDF = async () => {
    if (!activeReceipt) return;
    const element = document.getElementById('printable-invoice');
    if (!element) return;

    setIsExportingPDF(true);
    const originalGetComputedStyle = window.getComputedStyle;

    try {
      // Temporarily mock getComputedStyle to replace any oklch(...) and oklab(...) colors with rgb/rgba fallback
      window.getComputedStyle = function (elt, pseudoElt) {
        const style = originalGetComputedStyle.call(this, elt, pseudoElt);
        return new Proxy(style, {
          get(target, prop) {
            if (prop === 'getPropertyValue') {
              return (propertyName: string) => {
                const val = target.getPropertyValue(propertyName);
                return replaceOklchAndOklabWithRgb(val);
              };
            }
            const value = (target as any)[prop];
            if (typeof value === 'function') {
              return value.bind(target);
            }
            if (typeof value === 'string') {
              return replaceOklchAndOklabWithRgb(value);
            }
            return value;
          }
        });
      };

      // Small timeout to let UI settle if needed
      await new Promise(resolve => setTimeout(resolve, 150));
      
      const canvas = await html2canvas(element, {
        scale: 2.5, // Crisp resolution
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgWidth = 210; // A4 size width in mm
      const pageHeight = 297; // A4 size height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`فاتورة_رقم_${activeReceipt.id}.pdf`);
    } catch (err) {
      console.error('Error exporting PDF:', err);
    } finally {
      window.getComputedStyle = originalGetComputedStyle;
      setIsExportingPDF(false);
    }
  };

  if (activeReceipt) {
    const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

    return (
      <div className="space-y-8 animate-fade-in text-right" dir="rtl">
        {/* Navigation & Action Bar on Screen (Hidden on Print) */}
        <div className="no-print flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
          <div>
            <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <FileText className="text-slate-950" size={24} />
              <span>مراجعة الفاتورة التفصيلية</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              مراجعة شاملة لبيانات الفاتورة والأصناف قبل الطباعة أو التصدير
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            {/* 1. Print Button */}
            <button 
              onClick={() => {
                if (isInIframe) {
                  setShowIframePrintModal(true);
                } else {
                  try {
                    window.focus();
                    window.print();
                  } catch (err) {
                    console.error("Print command failed: ", err);
                  }
                }
              }}
              className="flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-bold px-4 py-2.5 rounded-lg transition-colors text-xs active:scale-98 cursor-pointer shadow-xs"
            >
              <Printer size={15} />
              <span>طباعة الفاتورة ورَقياً</span>
            </button>

            {/* 2. Programmatic PDF Export Button */}
            <button 
              onClick={handleExportPDF}
              disabled={isExportingPDF}
              className={`flex items-center justify-center gap-2 text-white font-bold px-4 py-2.5 rounded-lg transition-colors text-xs active:scale-98 cursor-pointer shadow-xs ${
                isExportingPDF 
                  ? 'bg-indigo-400 cursor-not-allowed opacity-80' 
                  : 'bg-indigo-600 hover:bg-indigo-700'
              }`}
            >
              {isExportingPDF ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>جاري تصدير الـ PDF...</span>
                </>
              ) : (
                <>
                  <Download size={15} />
                  <span>تصدير الفاتورة PDF</span>
                </>
              )}
            </button>

            {/* 3. Back Button */}
            <button 
              onClick={() => setActiveReceipt(null)}
              className="flex items-center justify-center gap-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold px-4 py-2.5 rounded-lg transition-all text-xs cursor-pointer active:scale-98"
            >
              <ArrowRight size={15} />
              <span>العودة للأرشيف</span>
            </button>
          </div>
        </div>

        {/* Custom modal for iframe sandbox print block */}
        <AnimatePresence>
          {showIframePrintModal && (
            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4" dir="rtl">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden"
              >
                <div className="bg-amber-500 p-5 text-white flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <AlertTriangle size={20} className="shrink-0" />
                    <h3 className="font-bold text-sm">قيود أمان المتصفح (حظر نوافذ الطباعة)</h3>
                  </div>
                  <button 
                    onClick={() => setShowIframePrintModal(false)}
                    className="text-white/80 hover:text-white cursor-pointer transition-colors p-1"
                  >
                    <XIcon size={18} />
                  </button>
                </div>

                <div className="p-6 space-y-4">
                  <p className="text-xs text-slate-600 leading-relaxed">
                    المتصفح يمنع استدعاء أمر الطباعة المباشر <strong>window.print()</strong> داخل إطار المعاينة الصغير (Sandbox Iframe) لحمايتك.
                  </p>
                  
                  <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 text-right space-y-2">
                    <p className="text-xs font-bold text-slate-800">💡 الحل السريع والمباشر:</p>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      يرجى فتح التطبيق في <strong>علامة تبويب كاملة ومستقلة</strong> عن طريق الضغط على زر "فتح في نافذة جديدة" المتواجد أعلى يمين شاشة المعاينة (أيقونة المربع وبداخله سهم مائل). هناك ستعمل الطباعة وتصدير PDF بكفاءة ١٠٠٪!
                    </p>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-[11px] font-semibold text-slate-500">رابط التطبيق المباشر:</label>
                    <div className="flex gap-2 font-mono">
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(window.location.href);
                          setCopied(true);
                          setTimeout(() => setCopied(false), 2000);
                        }}
                        className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-lg text-xs transition-colors cursor-pointer border border-slate-200 font-sans"
                      >
                        {copied ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
                        <span>{copied ? 'تم النسخ!' : 'نسخ الرابط'}</span>
                      </button>
                      <input 
                        type="text" 
                        readOnly 
                        value={window.location.href} 
                        className="w-full text-left bg-slate-50 border border-slate-200 text-xs px-3 py-2 rounded-lg outline-none text-slate-500 truncate"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex gap-3 justify-end">
                  <button
                    onClick={() => setShowIframePrintModal(false)}
                    className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs px-4 py-2.5 rounded-lg transition-all font-bold cursor-pointer"
                  >
                    إغلاق التنبيه
                  </button>
                  <button
                    onClick={() => {
                      window.open(window.location.href, '_blank');
                      setShowIframePrintModal(false);
                    }}
                    className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs px-4 py-2.5 rounded-lg transition-all font-bold cursor-pointer shadow-xs active:scale-98"
                  >
                    <ExternalLink size={14} />
                    <span>الذهاب والطباعة فوراً</span>
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Notice for iframe environments (Hidden on Print) */}
        {isInIframe && (
          <div className="no-print bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-start gap-3 text-amber-900 text-xs leading-relaxed max-w-4xl mx-auto shadow-xs">
            <AlertTriangle className="text-amber-600 shrink-0 mt-0.5" size={18} />
            <div className="space-y-1">
              <p className="font-bold">تنبيه لضمان عمل الطباعة وحفظ الـ PDF بشكل سليم:</p>
              <p>
                بما أنك تستعرض التطبيق حالياً داخل إطار المعاينة الجانبي، فقد تقوم سياسات الأمان في متصفحك بحظر نوافذ الطباعة (print dialogue).
              </p>
              <p className="font-semibold text-amber-950 mt-1">
                💡 الحل الأمثل: يرجى الضغط على زر "فتح في علامة تبويب جديدة" (الأيقونة ذات السهم أعلى يمين الشاشة) لفتح التطبيق بشكل كامل ومستقل، وستعمل ميزة الطباعة وحفظ PDF على الفور وبأعلى دقة!
              </p>
            </div>
          </div>
        )}

        {/* Printable Invoice Sheet Container */}
        <style dangerouslySetInnerHTML={{__html: `
          #printable-invoice, #printable-invoice * {
            letter-spacing: 0px !important;
            letter-spacing: normal !important;
          }
        `}} />
        <div 
          id="printable-invoice" 
          className="bg-white rounded-xl border border-slate-250 shadow-md p-8 max-w-4xl mx-auto space-y-8"
        >
          {/* Invoice Corporate Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-6 border-b border-slate-200 pb-6">
            <div className="space-y-2 text-right">
              <h2 className="text-xl font-black text-slate-900">{companySettings.companyName}</h2>
              <p className="text-xs text-slate-500 font-medium">
                {companySettings.commercialRegister && `سجل تجاري رقم: ${companySettings.commercialRegister}`}
                {companySettings.commercialRegister && companySettings.taxNumber && ' / '}
                {companySettings.taxNumber && `بطاقة ضريبية رقم: ${companySettings.taxNumber}`}
              </p>
              <p className="text-xs text-slate-500 font-medium">
                {companySettings.phone && `الهاتف: ${companySettings.phone}`}
                {companySettings.phone && companySettings.email && ' / '}
                {companySettings.email && `البريد: ${companySettings.email}`}
              </p>
            </div>
            <div className="space-y-2 sm:text-left text-right min-w-[200px] sm:self-center">
              <div className="inline-block bg-slate-900 text-white font-black text-xs px-4 py-1.5 rounded-md uppercase">
                فاتورة بيع مبسطة
              </div>
              <div className="text-xs text-slate-500 font-mono mt-1">
                رقم الفاتورة: <b className="text-slate-900 font-bold text-sm">#{activeReceipt.id}</b>
              </div>
              <div className="text-xs text-slate-500">
                تاريخ المعاملة: <b className="text-slate-900 font-mono font-medium">{new Date(activeReceipt.date).toLocaleString('ar-EG', { dateStyle: 'long', timeStyle: 'short' })}</b>
              </div>
            </div>
          </div>

          {/* Customer & Merchant Metadata Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 p-5 rounded-xl border border-slate-200/80">
            <div className="space-y-2.5 text-right">
              <h3 className="text-xs font-bold text-indigo-600 uppercase border-b border-indigo-100 pb-1.5">بيانات العميل (الطرف الثاني)</h3>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-450 font-semibold">اسم العميل بالكامل:</span>
                  <span className="font-bold text-slate-900">{activeReceipt.customerName}</span>
                </div>
                {activeReceipt.customerCode && (
                  <div className="flex justify-between">
                    <span className="text-slate-450 font-semibold">كود العميل الموحد:</span>
                    <span className="font-mono font-bold text-indigo-600">{activeReceipt.customerCode}</span>
                  </div>
                )}
                {activeReceipt.customerAddress && (
                  <div className="flex justify-between gap-4">
                    <span className="text-slate-450 font-semibold shrink-0">عنوان العميل:</span>
                    <span className="text-slate-800 font-medium text-left">{activeReceipt.customerAddress}</span>
                  </div>
                )}
                {/* Search for client phone if registerd */}
                {(() => {
                  const cust = customers.find(c => c.id === activeReceipt.customerCode);
                  if (cust && cust.phone) {
                    return (
                      <div className="flex justify-between">
                        <span className="text-slate-450 font-semibold">رقم هاتف العميل:</span>
                        <span className="font-mono text-slate-900">{cust.phone}</span>
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>
            </div>

            <div className="space-y-2.5 text-right">
              <h3 className="text-xs font-bold text-slate-500 uppercase border-b border-slate-200 pb-1.5 font-sans">معلومات جهة البيع (الطرف الأول)</h3>
              <div className="space-y-1.5 text-xs text-slate-700">
                <div className="flex justify-between">
                  <span className="text-slate-450 font-semibold">الجهة البائعة:</span>
                  <span className="font-bold text-slate-900">{companySettings.companyName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-450 font-semibold">المستودع الرئيسي:</span>
                  <span className="font-medium text-slate-800">{companySettings.mainWarehouse}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-450 font-semibold">الفرع المحلي المباشر:</span>
                  <span className="font-medium text-slate-800">{companySettings.localBranch}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-slate-900 text-white font-bold border-b border-slate-200">
                  <th className="py-3 px-4 font-bold text-right">#</th>
                  <th className="py-3 font-bold text-right">الصنف / اسم المنتج بالكامل</th>
                  <th className="py-3 font-bold text-center">سعر الوحدة</th>
                  <th className="py-3 font-bold text-center">الكمية</th>
                  <th className="py-3 px-4 font-bold text-left">المجموع الإجمالي</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-150">
                {activeReceipt.items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-slate-450 font-mono">{idx + 1}</td>
                    <td className="py-3.5 font-bold text-slate-900">{item.productName}</td>
                    <td className="py-3.5 text-center font-mono text-slate-600">{item.sellPrice.toFixed(2)} ج.م</td>
                    <td className="py-3.5 text-center font-mono font-bold text-slate-900">{item.quantity}</td>
                    <td className="py-3.5 px-4 text-left font-mono font-bold text-slate-950">{(item.sellPrice * item.quantity).toFixed(2)} ج.م</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Financial calculations & Signature Blocks */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            {/* Notes & Terms */}
            <div className="space-y-4 text-right self-start">
              {activeReceipt.notes && (
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs text-slate-600 leading-relaxed">
                  <b className="text-slate-800 block mb-1">ملاحظات وشروط الفاتورة:</b>
                  {activeReceipt.notes}
                </div>
              )}
              <div className="p-4 bg-indigo-50/30 rounded-xl border border-indigo-100/50 text-[10px] text-slate-500 leading-relaxed space-y-1">
                <p className="font-bold text-indigo-950">ملاحظات هامة للطباعة والاستلام:</p>
                <p>• تعتبر هذه الفاتورة مستند استلام سليم لكافة البضائع الموضحة أعلاه.</p>
                <p>• يُرجى مراجعة كافة الكميات والأسعار قبل مغادرة نقطة التوريد.</p>
              </div>
            </div>

            {/* Price Calculations Column */}
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-xs space-y-3">
              <div className="flex justify-between text-slate-600 border-b border-slate-200 pb-2">
                <span className="font-semibold">إجمالي الأصناف والمنتجات:</span>
                <span className="font-mono font-bold text-slate-800">
                  {activeReceipt.items.reduce((acc, item) => acc + (item.sellPrice * item.quantity), 0).toFixed(2)} ج.م
                </span>
              </div>
              
              {/* Calculate discount if any */}
              {(() => {
                const totalItems = activeReceipt.items.reduce((acc, item) => acc + (item.sellPrice * item.quantity), 0);
                const discount = totalItems - activeReceipt.totalAmount;
                if (discount > 0.01) {
                  return (
                    <div className="flex justify-between text-rose-700 border-b border-slate-200 pb-2">
                      <span className="font-semibold">خصم نقدي مباشر:</span>
                      <span className="font-mono font-bold">-{discount.toFixed(2)} ج.م</span>
                    </div>
                  );
                }
                return null;
              })()}

              <div className="flex justify-between text-slate-900 font-bold text-sm border-b border-slate-250 pb-2.5">
                <span>الصافي المطلوب سداده:</span>
                <span className="font-mono text-indigo-700 text-base">{activeReceipt.totalAmount.toFixed(2)} ج.م</span>
              </div>

              <div className="flex justify-between text-slate-700 font-semibold border-b border-slate-200 pb-2">
                <span>المبلغ المدفوع نقداً:</span>
                <span className="font-mono text-emerald-700 font-bold">{activeReceipt.paidAmount.toFixed(2)} ج.م</span>
              </div>

              <div className="flex justify-between font-bold text-slate-950">
                <span>المتبقي (حساب آجل):</span>
                <span className={`font-mono text-sm ${activeReceipt.remainingAmount > 0 ? 'text-amber-800 font-black' : 'text-slate-400'}`}>
                  {activeReceipt.remainingAmount.toFixed(2)} ج.م
                </span>
              </div>
            </div>
          </div>

          {/* Seal and Signatures */}
          <div className="pt-8 border-t border-slate-100 flex justify-between items-center text-center text-xs text-slate-450 gap-6">
            <div className="space-y-6 flex-1">
              <span className="block font-semibold">توقيع المستلم (العميل)</span>
              <div className="h-10 border-b border-dashed border-slate-250 w-2/3 mx-auto font-sans"></div>
            </div>
            <div className="space-y-6 flex-1">
              <span className="block font-semibold">الختم الرسمي للجهة البائعة</span>
              <div className="w-14 h-14 bg-slate-50 border border-slate-200 rounded-full mx-auto flex items-center justify-center font-mono text-[9px] text-slate-400 font-bold border-dashed uppercase">
                STAMP
              </div>
            </div>
            <div className="space-y-6 flex-1">
              <span className="block font-semibold">توقيع المسؤول المالي / المحاسب</span>
              <div className="h-10 border-b border-dashed border-slate-250 w-2/3 mx-auto font-sans"></div>
            </div>
          </div>
        </div>

        {/* Bottom Back Button (Screen Only) */}
        <div className="no-print flex justify-center pt-2">
          <button 
            onClick={() => setActiveReceipt(null)}
            className="flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-bold px-8 py-3 rounded-xl transition-all text-xs cursor-pointer shadow-md hover:shadow-lg active:scale-98"
          >
            <ArrowRight size={14} />
            <span>الرجوع لقائمة المبيعات والأرشيف</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in" id="sales-tab" dir="rtl">
      {/* Title & Internal Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-xl font-bold text-slate-900">إدارة فواتير المبيعات ونقاط البيع</h1>
          <p className="text-xs text-slate-500 mt-1">سجل معاملاتك، تتبع الأرباح المباشرة واحسب الديون والآجل للزبائن</p>
        </div>
        
        {/* Sub Navigation Tabs */}
        <div className="flex bg-slate-50 border border-slate-200 p-1 rounded-lg self-start">
          <button 
            onClick={() => setSalesSubTab('pos')}
            className={`px-4 py-2 text-xs font-bold rounded-md transition-all cursor-pointer ${
              salesSubTab === 'pos' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-550 hover:text-slate-800'
            }`}
          >
            نقطة بيع جديدة (POS)
          </button>
          <button 
            onClick={() => setSalesSubTab('history')}
            className={`px-4 py-2 text-xs font-bold rounded-md transition-all cursor-pointer ${
              salesSubTab === 'history' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-550 hover:text-slate-800'
            }`}
          >
            سجل الفواتير السابقة ({sales.length})
          </button>
        </div>
      </div>

      {salesSubTab === 'pos' ? (
        /* ================== POS TERMINAL VIEW ================== */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Right Column: Add items form & Cart items (2 Cols wide) */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Adding item form */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
                <ShoppingCart size={15} className="text-slate-900" />
                <span>إضافة صنف للفاتورة الحالية</span>
              </h2>

              <form onSubmit={handleAddToInvoice} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 items-end">
                {/* Product Code / Barcode Input */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">كود / باركود المنتج</label>
                  <input 
                    type="text"
                    value={typedProductCode}
                    placeholder="مثال: PROD-102"
                    onChange={(e) => {
                      const code = e.target.value;
                      setTypedProductCode(code);
                      
                      // Immediate search for match (case-insensitive and trimmed)
                      const match = products.find(p => p.id.trim().toLowerCase() === code.trim().toLowerCase());
                      if (match) {
                        setSelectedProductId(match.id);
                      } else {
                        setSelectedProductId('');
                      }
                    }}
                    className="w-full text-right bg-slate-50 border border-slate-200 text-xs px-3 py-2.5 rounded-lg outline-none focus:border-slate-900 focus:bg-white font-mono font-bold"
                  />
                </div>

                {/* Select Product */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">أو اختر المنتج من القائمة</label>
                  <select 
                    value={selectedProductId}
                    onChange={(e) => {
                      const val = e.target.value;
                      setSelectedProductId(val);
                      setTypedProductCode(val);
                      setSelectedQuantity('1');
                    }}
                    required={!typedProductCode}
                    className="w-full text-right bg-slate-50 border border-slate-200 text-xs px-3 py-2.5 rounded-lg outline-none focus:border-slate-900 focus:bg-white cursor-pointer font-bold"
                  >
                    <option value="">-- اختر منتج --</option>
                    {products.map(p => (
                      <option key={p.id} value={p.id} disabled={p.stock <= 0}>
                        {p.name} ({p.stock} قطعة بالداخل) - {p.sellPrice} ج.م
                      </option>
                    ))}
                  </select>
                </div>

                {/* Quantity Input */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">الكمية المطلوبة</label>
                  <input 
                    type="number"
                    min="1"
                    required
                    disabled={!selectedProductId}
                    value={selectedQuantity}
                    onChange={(e) => setSelectedQuantity(e.target.value)}
                    className="w-full text-right bg-slate-50 border border-slate-200 text-xs px-3 py-2.5 rounded-lg outline-none focus:border-slate-900 focus:bg-white font-mono"
                  />
                </div>

                {/* Submit button */}
                <button 
                  type="submit"
                  disabled={!selectedProductId}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg transition-colors active:scale-98 disabled:bg-slate-100 disabled:text-slate-400 text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Plus size={14} />
                  <span>أضف للسلة</span>
                </button>
              </form>

              {/* Selection details callback */}
              {currentProduct && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200/60 flex items-center justify-between text-xs">
                  <span className="text-slate-500">سعر القطعة: <b className="text-slate-800">{currentProduct.sellPrice} ج.م</b></span>
                  <span className="text-slate-500">المخزون المتوفر: <b className={`${currentProduct.stock <= currentProduct.minStockAlert ? 'text-amber-600' : 'text-slate-800'}`}>{currentProduct.stock} قطعة</b></span>
                  <span className="text-slate-900 font-bold">المجموع: {currentProduct.sellPrice * (parseInt(selectedQuantity) || 0)} ج.م</span>
                </div>
              )}
            </div>

            {/* Cart Items List */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
              <h2 className="text-sm font-bold text-slate-900">الأصناف المضافة للفاتورة</h2>

              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 pb-3">
                      <th className="pb-3 font-semibold">الصنف</th>
                      <th className="pb-3 font-semibold text-center">سعر الوحدة</th>
                      <th className="pb-3 font-semibold text-center">الكمية</th>
                      <th className="pb-3 font-semibold text-left">الإجمالي</th>
                      <th className="pb-3 font-semibold text-center">حذف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-150">
                    {cartItems.length > 0 ? (
                      cartItems.map((item) => (
                        <tr key={item.productId} className="text-slate-700 hover:bg-slate-50/50 transition-colors">
                          <td className="py-3">
                            <span className="font-bold text-slate-900">{item.productName}</span>
                            <span className="block text-[10px] text-slate-400 font-mono mt-0.5">باركود: {item.productId}</span>
                          </td>
                          <td className="py-3 text-center font-mono">{item.sellPrice.toFixed(2)} ج.م</td>
                          <td className="py-3 text-center font-mono font-bold text-slate-900">{item.quantity}</td>
                          <td className="py-3 text-left font-mono font-bold text-slate-800">{item.total.toFixed(2)} ج.م</td>
                          <td className="py-3 text-center">
                            <button 
                              onClick={() => handleRemoveFromCart(item.productId)}
                              className="p-1.5 text-rose-700 bg-rose-50 border border-rose-100 hover:bg-rose-100 rounded-md transition-colors"
                            >
                              <Trash2 size={13} />
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="text-center py-12 text-slate-400">
                          🛒 السلة فارغة حالياً. اختر منتجاً من الأعلى وأضفه لبدء البيع.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>

          {/* Left Column: Checkout Summary & Customer details (1 Col wide) */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 h-fit space-y-6">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
              <UserCheck size={15} className="text-slate-900" />
              <span>تفاصيل الدفع والعميل</span>
            </h2>

            <div className="space-y-4">
              {/* Registered Customer Selection */}
              {customers.length > 0 && (
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">اختر من العملاء المسجلين</label>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => {
                      const cid = e.target.value;
                      setSelectedCustomerId(cid);
                      const chosen = customers.find(c => c.id === cid);
                      if (chosen) {
                        setCustomerName(chosen.name);
                      } else {
                        setCustomerName('');
                      }
                    }}
                    className="w-full text-right bg-slate-50 border border-slate-200 text-xs px-3 py-2.5 rounded-lg outline-none focus:border-slate-900 focus:bg-white cursor-pointer font-bold"
                  >
                    <option value="">-- عميل عام (غير مسجل) --</option>
                    {customers.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.id})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Customer Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">
                  {selectedCustomerId ? 'اسم العميل المختار (مسجل)' : 'اسم العميل بالكامل (اختياري)'}
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 right-3 flex items-center text-slate-400">
                    <User size={14} />
                  </span>
                  <input 
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    disabled={!!selectedCustomerId}
                    placeholder="زبون عام / زبون آجل"
                    className={`w-full text-right text-xs px-9 py-2.5 rounded-lg outline-none border transition-all ${
                      selectedCustomerId 
                        ? 'bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed font-bold' 
                        : 'bg-slate-50 border-slate-200 focus:border-slate-900 focus:bg-white'
                    }`}
                  />
                </div>
              </div>

              {/* Customer Preview Card */}
              {selectedCustomerId && (() => {
                const chosen = customers.find(c => c.id === selectedCustomerId);
                if (!chosen) return null;
                return (
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs text-slate-700 space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-semibold">كود العميل:</span>
                      <span className="font-mono font-bold text-slate-900">{chosen.id}</span>
                    </div>
                    {chosen.address && (
                      <div className="flex justify-between gap-2">
                        <span className="text-slate-400 font-semibold shrink-0">عنوان العميل:</span>
                        <span className="text-right font-medium text-slate-950">{chosen.address}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-semibold">رقم الهاتف:</span>
                      <span className="font-mono text-slate-900">{chosen.phone}</span>
                    </div>
                  </div>
                );
              })()}

              {/* Discount Amount */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5 flex justify-between">
                  <span>خصم مباشر بالفاتورة (جنية)</span>
                  <span className="text-[10px] text-slate-400 flex items-center gap-0.5"><Tag size={10} /> خصم مالي</span>
                </label>
                <input 
                  type="number"
                  min="0"
                  max={subTotal}
                  value={discountAmount}
                  onChange={(e) => setDiscountAmount(e.target.value)}
                  className="w-full text-right bg-slate-50 border border-slate-200 text-xs px-3 py-2.5 rounded-lg outline-none focus:border-slate-900 focus:bg-white font-mono"
                  placeholder="0.00"
                />
              </div>

              {/* Paid Amount */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">المبلغ المدفوع فعلياً (جنية)</label>
                <input 
                  type="number"
                  min="0"
                  max={grandTotal}
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  placeholder={`الكل: ${grandTotal.toFixed(2)}`}
                  className="w-full text-right bg-slate-50 border border-slate-200 text-xs px-3 py-2.5 rounded-lg outline-none focus:border-slate-900 focus:bg-white font-mono"
                />
                <span className="text-[10px] text-slate-400 block mt-1">اتركه فارغاً إذا دفع الزبون الفاتورة بالكامل</span>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">ملاحظات الفاتورة (اختياري)</label>
                <textarea 
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full text-right bg-slate-50 border border-slate-200 text-xs px-3 py-2.5 rounded-lg outline-none focus:border-slate-900 focus:bg-white resize-none"
                  placeholder="مثال: تسليم مبيعات الدفعة الثانية"
                />
              </div>

              {/* Financial Breakdown Panel */}
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 text-xs space-y-2.5">
                <div className="flex items-center justify-between text-slate-500 font-medium">
                  <span>المجموع الفرعي:</span>
                  <span className="font-mono">{subTotal.toFixed(2)} ج.م</span>
                </div>
                {discount > 0 && (
                  <div className="flex items-center justify-between text-rose-700 font-semibold">
                    <span>الخصم المطبق:</span>
                    <span className="font-mono">-{discount.toFixed(2)} ج.م</span>
                  </div>
                )}
                <div className="flex items-center justify-between text-slate-900 font-bold border-t border-slate-200 pt-2.5 text-sm">
                  <span>صافي الفاتورة الكلي:</span>
                  <span className="font-mono text-slate-900">{grandTotal.toFixed(2)} ج.م</span>
                </div>
                
                {remainingAmount > 0 && (
                  <div className="flex items-center justify-between text-amber-900 font-bold bg-amber-50 p-2 rounded border border-amber-200 mt-1">
                    <span>المتبقي في الآجل (دين):</span>
                    <span className="font-mono">+{remainingAmount.toFixed(2)} ج.م</span>
                  </div>
                )}
              </div>

              {/* Checkout Trigger */}
              <button 
                type="button"
                onClick={handleCheckout}
                disabled={cartItems.length === 0}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg transition-colors active:scale-98 disabled:bg-slate-100 disabled:text-slate-400 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <CheckCircle size={15} />
                <span>حفظ وطباعة الفاتورة</span>
              </button>
            </div>
          </div>

        </div>
      ) : (
        /* ================== INVOICE HISTORY VIEW ================== */
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileText size={15} className="text-slate-900" />
              <span>أرشيف وسجل المبيعات</span>
            </h2>

            {/* Search Input in History */}
            <div className="relative max-w-xs w-full">
              <span className="absolute inset-y-0 right-3 flex items-center text-slate-450">
                <Search size={14} />
              </span>
              <input 
                type="text"
                placeholder="ابحث برقم الفاتورة أو العميل..."
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                className="w-full text-right bg-slate-50 border border-slate-200 focus:border-slate-900 focus:bg-white text-xs px-9 py-2 rounded-lg outline-none transition-all"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-450 bg-slate-50/50">
                  <th className="py-3 px-3 font-bold">رقم الفاتورة</th>
                  <th className="py-3 font-bold">تاريخ البيع</th>
                  <th className="py-3 font-bold">اسم العميل</th>
                  <th className="py-3 font-bold">محتويات الفاتورة</th>
                  <th className="py-3 font-bold text-left">قيمة الفاتورة</th>
                  <th className="py-3 font-bold text-left">المدفوع</th>
                  <th className="py-3 font-bold text-left">المتبقي (آجل)</th>
                  <th className="py-3 font-bold text-center">حالة الربح</th>
                  <th className="py-3 px-3 font-bold text-center">خيارات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-150">
                {filteredSales.length > 0 ? (
                  filteredSales.slice().reverse().map((sale) => (
                    <tr key={sale.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-3.5 px-3 font-bold text-slate-900">#{sale.id}</td>
                      <td className="py-3.5 text-slate-500">{new Date(sale.date).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })}</td>
                      <td className="py-3.5 font-bold text-slate-800">
                        <div>{sale.customerName}</div>
                        {sale.customerCode && (
                          <div className="text-[10px] text-indigo-600 font-mono mt-0.5">كود: {sale.customerCode}</div>
                        )}
                        {sale.customerAddress && (
                          <div className="text-[10px] text-slate-400 font-normal mt-0.5 max-w-[150px] truncate" title={sale.customerAddress}>
                            العنوان: {sale.customerAddress}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 text-slate-500 max-w-[180px] truncate" title={sale.items.map(i => `${i.productName} (${i.quantity})`).join(', ')}>
                        {sale.items.map(i => `${i.productName} (${i.quantity})`).join('، ')}
                      </td>
                      <td className="py-3.5 text-left font-mono font-bold text-slate-900">{sale.totalAmount.toFixed(2)} ج.م</td>
                      <td className="py-3.5 text-left font-mono font-semibold text-slate-800">{sale.paidAmount.toFixed(2)} ج.م</td>
                      <td className="py-3.5 text-left font-mono">
                        <span className={sale.remainingAmount > 0 ? 'text-amber-800 font-bold' : 'text-slate-400'}>
                          {sale.remainingAmount.toFixed(2)} ج.م
                        </span>
                      </td>
                      <td className="py-3.5 text-center">
                        <span className="inline-block bg-slate-50 border border-slate-200 text-slate-700 font-bold font-mono px-2 py-0.5 rounded text-[10px]">
                          +{sale.totalProfit.toFixed(2)} ج.م
                        </span>
                      </td>
                      <td className="py-3.5 px-3">
                        <div className="flex items-center justify-center gap-1.5">
                          <button 
                            onClick={() => setActiveReceipt(sale)}
                            className="p-1.5 text-slate-700 bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                            title="عرض الفاتورة المصغرة"
                          >
                            <Printer size={13} />
                          </button>
                          <button 
                            onClick={() => setSaleToRefund(sale)}
                            className="p-1.5 text-rose-700 bg-rose-50 border border-rose-100 hover:bg-rose-100 rounded-md transition-colors cursor-pointer"
                            title="إلغاء وارتجاع الفاتورة"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={9} className="text-center py-12 text-slate-400">
                      لا توجد فواتير مبيعات مسجلة في الأرشيف تطابق معايير البحث.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL - Mobile Friendly Digital Invoice / Receipt Print View */}
      <AnimatePresence>
        {/* Modal - Confirm Refund Sale */}
        {saleToRefund && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" dir="rtl">
            <motion.div 
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              className="bg-white rounded-xl w-full max-w-md border border-slate-200 shadow-xl overflow-hidden relative my-8 p-6 space-y-4 text-right animate-fade-in"
            >
              <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
                <div className="p-2 bg-rose-50 border border-rose-100 rounded-md text-rose-700">
                  <AlertTriangle size={18} />
                </div>
                <h3 className="text-sm font-bold text-slate-900">تأكيد استرجاع الفاتورة</h3>
              </div>
              
              <p className="text-xs text-slate-600 leading-relaxed">
                هل أنت متأكد من رغبتك في استرجاع الفاتورة رقم <b className="text-slate-900 font-mono">"{saleToRefund.id}"</b> بالكامل؟
                <span className="block mt-1.5 text-slate-700">العميل: <b className="text-slate-900">{saleToRefund.customerName}</b></span>
                <span className="block text-slate-700">القيمة الإجمالية: <b className="text-slate-900">{saleToRefund.totalAmount.toFixed(2)} ج.م</b></span>
                <span className="block mt-2 text-rose-600 font-semibold text-[10px]">سيتم مسح هذه الفاتورة من الأرشيف نهائياً وإرجاع كافة كميات الأصناف المشتراة إلى المخزن تلقائياً.</span>
              </p>

              <div className="pt-2 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setSaleToRefund(null)}
                  className="flex-1 py-2 rounded-lg text-slate-500 bg-slate-50 border border-slate-200 hover:bg-slate-100 font-semibold text-xs transition-colors cursor-pointer"
                >
                  تراجع
                </button>
                <button 
                  type="button"
                  onClick={() => {
                    onRefundSale(saleToRefund.id);
                    setSaleToRefund(null);
                  }}
                  className="flex-1 py-2 rounded-lg text-white bg-rose-600 hover:bg-rose-700 font-semibold text-xs transition-colors cursor-pointer active:scale-98"
                >
                  نعم، استرجع الفاتورة
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Simple Helper X close icon mapping
const X = ({ className, size }: { className?: string, size?: number }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size || 24} 
    height={size || 24} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
);
