import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, 
  Layers, 
  ShoppingCart, 
  FileSpreadsheet, 
  Download, 
  Info,
  Laptop,
  CheckCircle,
  Smartphone,
  PlusCircle,
  Users,
  Calendar,
  Undo2,
  Building2
} from 'lucide-react';
import { Product, Sale, Customer, RefundTransaction, CompanySettings } from './types';
import Dashboard from './components/Dashboard';
import ProductManager from './components/ProductManager';
import SalesManager from './components/SalesManager';
import ExcelHub from './components/ExcelHub';
import AddProduct from './components/AddProduct';
import EditProduct from './components/EditProduct';
import CustomerManager from './components/CustomerManager';
import EditCustomer from './components/EditCustomer';
import AddCustomer from './components/AddCustomer';
import ExpiryManager from './components/ExpiryManager';
import ReturnsManager from './components/ReturnsManager';
import CompanySettingsManager from './components/CompanySettingsManager';
import { exportToExcel } from './utils/excelUtils';

// Seeding Default Products
const defaultProducts: Product[] = [
  {
    id: 'BAR-1001',
    name: 'آيفون ١٥ برو ماكس ٢٥٦ جيجا',
    category: 'أجهزة ذكية',
    buyPrice: 48000,
    sellPrice: 55000,
    stock: 12,
    minStockAlert: 3,
    description: 'نسخة الشرق الأوسط بضمان محلي عامين'
  },
  {
    id: 'BAR-1002',
    name: 'سماعة أبل AirPods Pro ٢',
    category: 'سماعات',
    buyPrice: 3800,
    sellPrice: 4500,
    stock: 20,
    minStockAlert: 5,
    description: 'سماعات لاسلكية تدعم عزل الضوضاء النشط'
  },
  {
    id: 'BAR-1003',
    name: 'شاحن مغناطيسي لاسلكي سريع',
    category: 'إكسسوارات',
    buyPrice: 650,
    sellPrice: 1200,
    stock: 4,
    minStockAlert: 5,
    description: 'قوة ١٥ واط متوافق بالكامل مع MagSafe'
  },
  {
    id: 'BAR-1004',
    name: 'ساعة ذكية رياضية مقاومة للماء',
    category: 'ساعات ذكية',
    buyPrice: 2200,
    sellPrice: 2900,
    stock: 8,
    minStockAlert: 3,
    description: 'حساسات لقياس نبضات القلب ونسبة الأكسجين'
  },
  {
    id: 'BAR-1005',
    name: 'كابل شحن سريع USB-C ٢ متر',
    category: 'إكسسوارات',
    buyPrice: 180,
    sellPrice: 350,
    stock: 35,
    minStockAlert: 8,
    description: 'كابل شاحن مضفر بالنايلون فائق المتانة للقطع'
  },
  {
    id: 'BAR-1006',
    name: 'باور بنك شحن سريع ٢٠ ألف مللي أمبير',
    category: 'إكسسوارات',
    buyPrice: 1200,
    sellPrice: 1800,
    stock: 2,
    minStockAlert: 5,
    description: 'شاحن متنقل بمخرجين شحن سريع PD بقوة ٢٢.٥ واط'
  }
];

// Seeding Default Sales History (Yesterday and Today)
const getDefaultSales = (): Sale[] => {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  
  const today = new Date();

  return [
    {
      id: '985421',
      date: yesterday.toISOString(),
      customerName: 'أحمد أيمن (عميل تجريبي)',
      items: [
        {
          productId: 'BAR-1002',
          productName: 'سماعة أبل AirPods Pro ٢',
          quantity: 1,
          buyPrice: 3800,
          sellPrice: 4500,
          total: 4500,
          profit: 700
        },
        {
          productId: 'BAR-1003',
          productName: 'شاحن مغناطيسي لاسلكي سريع',
          quantity: 1,
          buyPrice: 650,
          sellPrice: 1200,
          total: 1200,
          profit: 550
        }
      ],
      totalAmount: 5700,
      paidAmount: 5700,
      remainingAmount: 0,
      totalProfit: 1250,
      notes: 'تم استلام الدفعة نقداً بالكامل'
    },
    {
      id: '204125',
      date: today.toISOString(),
      customerName: 'صلاح الدين',
      items: [
        {
          productId: 'BAR-1005',
          productName: 'كابل شحن سريع USB-C ٢ متر',
          quantity: 2,
          buyPrice: 180,
          sellPrice: 350,
          total: 700,
          profit: 340
        }
      ],
      totalAmount: 700,
      paidAmount: 500,
      remainingAmount: 200,
      totalProfit: 340,
      notes: 'متبقي ٢٠٠ جنية مستحقة الأسبوع القادم'
    }
  ];
};

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [refunds, setRefunds] = useState<RefundTransaction[]>([]);
  const [companySettings, setCompanySettings] = useState<CompanySettings>({
    companyName: 'الشركة الوطنية للمبيعات والتوريدات',
    mainWarehouse: 'فرع القاهرة والمحافظات',
    localBranch: 'نقطة بيع البيع السريع',
    commercialRegister: '١٠٢٩٣٨',
    taxNumber: '٤٥٦-٧٨٩-٠١٢',
    phone: '٠١٠٢٢٣٣٤٤٥٥',
    email: 'support@smartpos.com'
  });

  // Load products, sales, customers & refunds from LocalStorage or seed defaults
  useEffect(() => {
    const cachedProducts = localStorage.getItem('sales_app_products');
    const cachedSales = localStorage.getItem('sales_app_sales');
    const cachedCustomers = localStorage.getItem('sales_app_customers');
    const cachedRefunds = localStorage.getItem('sales_app_refunds');
    const cachedSettings = localStorage.getItem('sales_app_company_settings');

    if (cachedProducts) {
      setProducts(JSON.parse(cachedProducts));
    } else {
      setProducts(defaultProducts);
      localStorage.setItem('sales_app_products', JSON.stringify(defaultProducts));
    }

    if (cachedSales) {
      setSales(JSON.parse(cachedSales));
    } else {
      const initialSales = getDefaultSales();
      setSales(initialSales);
      localStorage.setItem('sales_app_sales', JSON.stringify(initialSales));
    }

    if (cachedCustomers) {
      setCustomers(JSON.parse(cachedCustomers));
    } else {
      const initialCustomers = [
        {
          id: 'CUST-1001',
          name: 'عميل نقدي افتراضي',
          phone: '01000000000',
          balance: 0,
          createdAt: '2026-07-01'
        },
        {
          id: 'CUST-1002',
          name: 'المهندس كريم محمود',
          phone: '01223456789',
          balance: 1500,
          createdAt: '2026-07-03',
          notes: 'عميل دائم مميز، لديه حساب آجل بقيمة 1500 جنيه'
        }
      ];
      setCustomers(initialCustomers);
      localStorage.setItem('sales_app_customers', JSON.stringify(initialCustomers));
    }

    if (cachedRefunds) {
      setRefunds(JSON.parse(cachedRefunds));
    } else {
      setRefunds([]);
    }

    if (cachedSettings) {
      setCompanySettings(JSON.parse(cachedSettings));
    }
  }, []);

  // Update localStorage whenever products, sales, customers, or refunds changes
  const saveProducts = (updatedProducts: Product[]) => {
    setProducts(updatedProducts);
    localStorage.setItem('sales_app_products', JSON.stringify(updatedProducts));
  };

  const saveSales = (updatedSales: Sale[]) => {
    setSales(updatedSales);
    localStorage.setItem('sales_app_sales', JSON.stringify(updatedSales));
  };

  const saveCustomers = (updatedCust: Customer[]) => {
    setCustomers(updatedCust);
    localStorage.setItem('sales_app_customers', JSON.stringify(updatedCust));
  };

  const saveRefunds = (updatedRefunds: RefundTransaction[]) => {
    setRefunds(updatedRefunds);
    localStorage.setItem('sales_app_refunds', JSON.stringify(updatedRefunds));
  };

  const saveCompanySettings = (updatedSettings: CompanySettings) => {
    setCompanySettings(updatedSettings);
    localStorage.setItem('sales_app_company_settings', JSON.stringify(updatedSettings));
  };

  // Customers handlers
  const handleAddCustomer = (newCustomer: Customer) => {
    saveCustomers([...customers, newCustomer]);
  };

  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    const updated = customers.map(c => c.id === updatedCustomer.id ? updatedCustomer : c);
    saveCustomers(updated);
  };

  const handleDeleteCustomer = (customerId: string) => {
    const updated = customers.filter(c => c.id !== customerId);
    saveCustomers(updated);
  };

  // Refunds and Returns handler
  const handleAddRefund = (newRefund: RefundTransaction) => {
    // 1. Add refund log
    const updatedRefunds = [...refunds, newRefund];
    saveRefunds(updatedRefunds);

    // 2. Adjust products inventory (restore quantities)
    const updatedProducts = products.map(p => {
      const returnedItem = newRefund.items.find(item => item.productId === p.id);
      if (returnedItem) {
        return {
          ...p,
          stock: p.stock + returnedItem.quantity
        };
      }
      return p;
    });
    saveProducts(updatedProducts);

    // 3. Mark the original sale as partially/fully refunded or update items
    const updatedSales = sales.map(s => {
      if (s.id === newRefund.saleId) {
        const updatedItems = s.items.map(sItem => {
          const refundedItem = newRefund.items.find(item => item.productId === sItem.productId);
          if (refundedItem) {
            const newQty = Math.max(0, sItem.quantity - refundedItem.quantity);
            return {
              ...sItem,
              quantity: newQty,
              total: newQty * sItem.sellPrice,
              profit: newQty * (sItem.sellPrice - sItem.buyPrice)
            };
          }
          return sItem;
        }).filter(item => item.quantity > 0);

        const newTotal = updatedItems.reduce((sum, item) => sum + item.total, 0);
        const newProfit = updatedItems.reduce((sum, item) => sum + item.profit, 0);

        return {
          ...s,
          items: updatedItems,
          totalAmount: newTotal,
          paidAmount: Math.min(s.paidAmount, newTotal),
          remainingAmount: Math.max(0, newTotal - s.paidAmount),
          totalProfit: newProfit,
          isRefunded: updatedItems.length === 0
        };
      }
      return s;
    });
    saveSales(updatedSales);
  };

  // Add Product handler
  const handleAddProduct = (newProduct: Product) => {
    saveProducts([...products, newProduct]);
  };

  // Edit/Update Product handler
  const handleUpdateProduct = (updatedProduct: Product) => {
    const updated = products.map(p => p.id === updatedProduct.id ? updatedProduct : p);
    saveProducts(updated);
  };

  // Delete Product handler
  const handleDeleteProduct = (productId: string) => {
    const updated = products.filter(p => p.id !== productId);
    saveProducts(updated);
  };

  // Bulk Import products from Excel
  const handleImportProducts = (imported: Product[]) => {
    // Merge strategy: if imported product ID matches existing, we overwrite, else we append
    const existingIds = new Set(products.map(p => p.id));
    const updatedList = [...products];

    imported.forEach(imp => {
      const index = updatedList.findIndex(p => p.id === imp.id);
      if (index !== -1) {
        // Overwrite existing
        updatedList[index] = imp;
      } else {
        // Append new
        updatedList.push(imp);
      }
    });

    saveProducts(updatedList);
  };

  // Checkout Sale handler
  const handleAddSale = (newSale: Sale) => {
    // 1. Deduct stock from products list
    const updatedProducts = products.map(product => {
      const purchasedItem = newSale.items.find(item => item.productId === product.id);
      if (purchasedItem) {
        return {
          ...product,
          stock: Math.max(0, product.stock - purchasedItem.quantity)
        };
      }
      return product;
    });

    saveProducts(updatedProducts);

    // 2. Add to sales log
    saveSales([...sales, newSale]);
  };

  // Refund Sale / Invoice handler
  const handleRefundSale = (saleId: string) => {
    const saleToRefund = sales.find(s => s.id === saleId);
    if (!saleToRefund) return;

    // Refund items back to stock
    const restoredProducts = products.map(product => {
      const refundedItem = saleToRefund.items.find(item => item.productId === product.id);
      if (refundedItem) {
        return {
          ...product,
          stock: product.stock + refundedItem.quantity
        };
      }
      return product;
    });

    saveProducts(restoredProducts);

    // Remove sale from history list
    const remainingSales = sales.filter(s => s.id !== saleId);
    saveSales(remainingSales);
  };

  const lowStockProductsCount = products.filter(p => p.stock <= p.minStockAlert).length;

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans relative pb-16 lg:pb-0" dir="rtl" id="app-root">
      
      {/* Top Professional Header Bar */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          
          {/* Logo & Branding */}
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-900 rounded-lg text-white flex items-center justify-center">
              <FileSpreadsheet size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm font-bold text-slate-900 tracking-tight leading-none">مبيعات إكسيل الذكي</h1>
                <span className="text-[10px] bg-slate-100 text-slate-700 font-bold px-2 py-0.5 rounded-md border border-slate-200/60">نشط</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-1">برنامج المبيعات المتكامل وتصدير الإكسيل للجوال</p>
            </div>
          </div>

          {/* Quick Export excel & Stock alerts indicator */}
          <div className="flex items-center gap-2.5">
            {lowStockProductsCount > 0 && (
              <div className="hidden sm:flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-amber-50/80 px-3 py-2 rounded-lg border border-amber-100">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-amber-500"></span>
                </span>
                <span>{lowStockProductsCount} نواقص بالمخزن</span>
              </div>
            )}
            
            <button 
              onClick={() => exportToExcel(products, sales)}
              className="flex items-center justify-center gap-1.5 bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 hover:border-slate-300 font-semibold px-4 py-2 rounded-lg transition-colors text-xs shadow-xs"
              title="تحميل شيت إكسيل فوري"
            >
              <Download size={14} />
              <span className="hidden sm:inline">تحميل شيت إكسيل للموبايل</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 max-w-7xl mx-auto w-full px-6 py-8 flex flex-col lg:flex-row gap-8">
        
        {/* Navigation Sidebar (Desktop view) */}
        <nav className="hidden lg:flex flex-col w-64 bg-white rounded-xl border border-slate-200 p-4 h-fit sticky top-24 shrink-0 space-y-1">
          <div className="text-[10px] font-bold text-slate-400 px-3 mb-2.5 uppercase tracking-wider">لوحات التحكم</div>
          
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'dashboard' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <TrendingUp size={15} />
              <span>لوحة الأرباح والمؤشرات</span>
            </div>
          </button>

          <button 
            onClick={() => setActiveTab('products')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'products' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Layers size={15} />
              <span>إدارة قائمة المخزن</span>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded-md font-mono ${activeTab === 'products' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200/40'}`}>
              {products.length}
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('add-product')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'add-product' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <PlusCircle size={15} />
              <span>إضافة منتج جديد</span>
            </div>
          </button>

          <button 
            onClick={() => setActiveTab('sales')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'sales' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <ShoppingCart size={15} />
              <span>مبيعات ونقاط بيع جديدة</span>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded-md font-mono ${activeTab === 'sales' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200/40'}`}>
              {sales.length}
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('excel')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'excel' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <FileSpreadsheet size={15} />
              <span>تصدير واستيراد إكسيل</span>
            </div>
          </button>

          <div className="text-[10px] font-bold text-slate-400 px-3 pt-3 mb-2.5 uppercase tracking-wider border-t border-slate-100">إدارة الخدمات المتقدمة</div>

          <button 
            onClick={() => setActiveTab('customers')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'customers' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Users size={15} />
              <span>تسجيل وإدارة العملاء</span>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded-md font-mono ${activeTab === 'customers' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200/40'}`}>
              {customers.length}
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('expiry')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'expiry' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Calendar size={15} />
              <span>نظام الأكسباير والتواريخ</span>
            </div>
            {products.filter(p => {
              if (!p.expiryDate) return false;
              const expDate = new Date(p.expiryDate);
              expDate.setHours(0,0,0,0);
              const today = new Date();
              today.setHours(0,0,0,0);
              const diffTime = expDate.getTime() - today.getTime();
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
              return diffDays <= 30; // Expired or expiring soon
            }).length > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-600 animate-pulse" />
            )}
          </button>

          <button 
            onClick={() => setActiveTab('returns')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'returns' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Undo2 size={15} />
              <span>نظام المرتجعات المالي</span>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded-md font-mono ${activeTab === 'returns' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200/40'}`}>
              {refunds.length}
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'settings' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Building2 size={15} />
              <span>بيانات الشركة والفواتير</span>
            </div>
          </button>

          {/* Quick Info Box in Sidebar */}
          <div className="border-t border-slate-100 pt-4 mt-4 text-[11px] text-slate-400 space-y-2 px-2">
            <div className="flex items-center gap-2 text-slate-500 font-semibold">
              <Smartphone size={13} />
              <span>متوافق مع الجوال</span>
            </div>
            <p className="leading-relaxed">
              افتح شيت المبيعات المصدر على هاتفك عبر تطبيق Excel مجاناً لرؤية الرسوم البيانية والمعادلات بالكامل.
            </p>
          </div>
        </nav>

        {/* Content Container */}
        <main className="flex-1 min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
              {activeTab === 'dashboard' && (
                <Dashboard 
                  products={products} 
                  sales={sales} 
                  onNavigate={setActiveTab} 
                />
              )}
              {activeTab === 'products' && (
                <ProductManager 
                  products={products}
                  onAddProduct={handleAddProduct}
                  onUpdateProduct={handleUpdateProduct}
                  onDeleteProduct={handleDeleteProduct}
                  onNavigate={setActiveTab}
                  onEditProduct={(p) => {
                    setEditingProduct(p);
                    setActiveTab('edit-product');
                  }}
                />
              )}
              {activeTab === 'edit-product' && editingProduct && (
                <EditProduct 
                  product={editingProduct}
                  onUpdateProduct={handleUpdateProduct}
                  onNavigate={setActiveTab}
                />
              )}
              {activeTab === 'add-product' && (
                <AddProduct 
                  products={products}
                  onAddProduct={handleAddProduct}
                  onNavigate={setActiveTab}
                />
              )}
              {activeTab === 'sales' && (
                <SalesManager 
                  products={products}
                  sales={sales}
                  customers={customers}
                  companySettings={companySettings}
                  onAddSale={handleAddSale}
                  onRefundSale={handleRefundSale}
                />
              )}
              {activeTab === 'excel' && (
                <ExcelHub 
                  products={products}
                  sales={sales}
                  onImportProducts={handleImportProducts}
                />
              )}
              {activeTab === 'customers' && (
                <CustomerManager 
                  customers={customers}
                  onAddCustomer={handleAddCustomer}
                  onUpdateCustomer={handleUpdateCustomer}
                  onDeleteCustomer={handleDeleteCustomer}
                  onEditCustomer={(cust) => {
                    setEditingCustomer(cust);
                    setActiveTab('edit-customer');
                  }}
                  onRegisterCustomerClick={() => {
                    setActiveTab('add-customer');
                  }}
                />
              )}
              {activeTab === 'add-customer' && (
                <AddCustomer 
                  customers={customers}
                  onAddCustomer={handleAddCustomer}
                  onNavigate={setActiveTab}
                />
              )}
              {activeTab === 'edit-customer' && editingCustomer && (
                <EditCustomer 
                  customer={editingCustomer}
                  onUpdateCustomer={handleUpdateCustomer}
                  onNavigate={setActiveTab}
                />
              )}
              {activeTab === 'expiry' && (
                <ExpiryManager 
                  products={products}
                  onUpdateProduct={handleUpdateProduct}
                />
              )}
              {activeTab === 'returns' && (
                <ReturnsManager 
                  sales={sales}
                  products={products}
                  refunds={refunds}
                  onAddRefund={handleAddRefund}
                />
              )}
              {activeTab === 'settings' && (
                <CompanySettingsManager 
                  settings={companySettings}
                  onUpdateSettings={saveCompanySettings}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile Sticky Navigation Bottom Bar (Responsive view only) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-sm px-4 py-2 flex items-center justify-around z-40">
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center gap-1 p-1 transition-colors ${
            activeTab === 'dashboard' ? 'text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          <TrendingUp size={18} />
          <span className="text-[10px]">الرئيسية</span>
        </button>

        <button 
          onClick={() => setActiveTab('products')}
          className={`flex flex-col items-center gap-1 p-1 transition-colors relative ${
            activeTab === 'products' ? 'text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          <Layers size={18} />
          <span className="text-[10px]">المخزن</span>
          {lowStockProductsCount > 0 && (
            <span className="absolute top-0 right-1.5 w-1.5 h-1.5 rounded-full bg-amber-500" />
          )}
        </button>

        <button 
          onClick={() => setActiveTab('add-product')}
          className={`flex flex-col items-center gap-1 p-1 transition-colors relative ${
            activeTab === 'add-product' ? 'text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          <PlusCircle size={18} />
          <span className="text-[10px]">إضافة منتج</span>
        </button>

        <button 
          onClick={() => setActiveTab('sales')}
          className={`flex flex-col items-center gap-1 p-1 transition-colors ${
            activeTab === 'sales' ? 'text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          <ShoppingCart size={18} />
          <span className="text-[10px]">المبيعات</span>
        </button>

        <button 
          onClick={() => setActiveTab('excel')}
          className={`flex flex-col items-center gap-1 p-1 transition-colors ${
            activeTab === 'excel' ? 'text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          <FileSpreadsheet size={18} />
          <span className="text-[10px]">إكسيل</span>
        </button>

        <button 
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center gap-1 p-1 transition-colors ${
            activeTab === 'settings' ? 'text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          <Building2 size={18} />
          <span className="text-[10px]">الشركة</span>
        </button>
      </nav>
      
    </div>
  );
}
