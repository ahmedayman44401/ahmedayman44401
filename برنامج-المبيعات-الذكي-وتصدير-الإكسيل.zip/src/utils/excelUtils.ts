import * as XLSX from 'xlsx';
import { Product, Sale } from '../types';

// Helper to format date
const formatDate = (dateStr: string) => {
  try {
    const d = new Date(dateStr);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  } catch {
    return dateStr;
  }
};

/**
 * Exports products and sales into a styled, formulas-equipped Excel Workbook (.xlsx)
 */
export const exportToExcel = (products: Product[], sales: Sale[]) => {
  const wb = XLSX.utils.book_new();

  // 1. Dashboard / Summary Sheet
  const dashboardData = [
    ['برنامج المبيعات الذكي وتصدير الإكسيل'],
    ['تم التصدير بتاريخ:', formatDate(new Date().toISOString())],
    [],
    ['إحصائيات عامة للمبيعات والمخزون', '', '', ''],
    ['المؤشر', 'القيمة الحالية', 'معادلة إكسيل النشطة', 'التوضيح'],
    ['إجمالي عدد المنتجات', products.length, '=COUNTA(المنتجات!B2:B1000)', 'عدد الأصناف المسجلة بالمخزن'],
    ['إجمالي المبيعات الفعلية', sales.reduce((sum, s) => sum + s.totalAmount, 0), '=SUM(المبيعات!E2:E5000)', 'مجموع المبالغ المحصلة من الفواتير'],
    ['إجمالي الأرباح المحققة', sales.reduce((sum, s) => sum + s.totalProfit, 0), '=SUM(المبيعات!H2:H5000)', 'صافي الربح من المبيعات الفعلية'],
    ['إجمالي القيمة الشرائية للمخزن', products.reduce((sum, p) => sum + (p.buyPrice * p.stock), 0), '=SUMPRODUCT(المنتجات!D2:D1000, المنتجات!F2:F1000)', 'رأس المال المستثمر في البضاعة الحالية'],
    ['إجمالي القيمة البيعية للمخزن', products.reduce((sum, p) => sum + (p.sellPrice * p.stock), 0), '=SUMPRODUCT(المنتجات!E2:E1000, المنتجات!F2:F1000)', 'القيمة البيعية المتوقعة للبضاعة الحالية'],
    ['الأرباح المتوقعة من البضاعة الحالية', products.reduce((sum, p) => sum + ((p.sellPrice - p.buyPrice) * p.stock), 0), '=J10-J9 (بيعي - شرائي)', 'صافي الأرباح المتوقع جنيها بعد بيع كامل المخزون'],
  ];

  const wsDashboard = XLSX.utils.aoa_to_sheet(dashboardData);

  // Set column widths for Dashboard
  wsDashboard['!cols'] = [
    { wch: 30 }, // Indicator
    { wch: 15 }, // Value
    { wch: 35 }, // Formula description
    { wch: 45 }, // Explanation
  ];

  // 2. Products Sheet
  const productsHeaders = [
    ['كود المنتج', 'اسم المنتج', 'القسم', 'سعر الشراء (تاريخي)', 'سعر البيع', 'الكمية الحالية', 'حد التنبيه', 'أرباح القطعة الواحدة']
  ];
  const productsRows = products.map((p, idx) => {
    const rowNum = idx + 2; // Row 1 is header
    return [
      p.id,
      p.name,
      p.category || 'عام',
      p.buyPrice,
      p.sellPrice,
      p.stock,
      p.minStockAlert || 5,
      { t: 'n', f: `E${rowNum}-D${rowNum}` } // Sell Price - Buy Price (Col E - Col D)
    ];
  });
  const wsProducts = XLSX.utils.aoa_to_sheet([...productsHeaders, ...productsRows]);
  wsProducts['!cols'] = [
    { wch: 15 }, // ID
    { wch: 25 }, // Name
    { wch: 15 }, // Category
    { wch: 15 }, // Buy Price
    { wch: 15 }, // Sell Price
    { wch: 15 }, // Stock
    { wch: 12 }, // Alert
    { wch: 18 }  // Unit Profit
  ];

  // 3. Sales Sheet
  const salesHeaders = [
    ['رقم الفاتورة', 'التاريخ والوقت', 'العميل', 'تفاصيل المنتجات والكميات', 'إجمالي الفاتورة', 'المدفوع', 'المتبقي (آجل)', 'صافي الربح']
  ];
  const salesRows = sales.map((s, idx) => {
    const rowNum = idx + 2;
    const itemsDetails = s.items.map(i => `${i.productName} (${i.quantity} × ${i.sellPrice})`).join(' | ');
    return [
      s.id,
      formatDate(s.date),
      s.customerName || 'زبون عام',
      itemsDetails,
      s.totalAmount,
      s.paidAmount,
      { t: 'n', f: `E${rowNum}-F${rowNum}` }, // Total - Paid (Col E - Col F)
      s.totalProfit
    ];
  });
  const wsSales = XLSX.utils.aoa_to_sheet([...salesHeaders, ...salesRows]);
  wsSales['!cols'] = [
    { wch: 15 }, // Invoice ID
    { wch: 20 }, // Date
    { wch: 20 }, // Customer
    { wch: 45 }, // Items Details
    { wch: 15 }, // Total
    { wch: 15 }, // Paid
    { wch: 15 }, // Remaining
    { wch: 15 }  // Profit
  ];

  // Append sheets
  XLSX.utils.book_append_sheet(wb, wsDashboard, 'الرئيسية');
  XLSX.utils.book_append_sheet(wb, wsProducts, 'المنتجات');
  XLSX.utils.book_append_sheet(wb, wsSales, 'المبيعات');

  // Trigger Excel file download
  XLSX.writeFile(wb, `برنامج_المبيعات_${formatDate(new Date().toISOString())}.xlsx`);
};

/**
 * Imports products from an uploaded Excel sheet.
 * Supported format expects sheet named 'المنتجات' or the first sheet in the workbook
 */
export const importProductsFromExcel = (file: File): Promise<Product[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) {
          throw new Error('فشل قراءة بيانات الملف');
        }

        const workbook = XLSX.read(data, { type: 'binary' });
        // Look for 'المنتجات' sheet, or fall back to the first sheet
        const sheetName = workbook.SheetNames.includes('المنتجات') 
          ? 'المنتجات' 
          : workbook.SheetNames[0];
        
        const worksheet = workbook.Sheets[sheetName];
        const rawRows: any[] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (rawRows.length <= 1) {
          throw new Error('الشيت فارغ أو لا يحتوي على صفوف بيانات');
        }

        const importedProducts: Product[] = [];
        // Header mapping
        // We assume headers: 0: كود المنتج, 1: اسم المنتج, 2: القسم, 3: سعر الشراء, 4: سعر البيع, 5: الكمية, 6: حد التنبيه
        const startRow = 1; // skip header row

        for (let i = startRow; i < rawRows.length; i++) {
          const row = rawRows[i];
          if (!row || row.length === 0 || !row[1]) continue; // Skip empty rows or rows without name

          const id = String(row[0] || `BAR-${Date.now()}-${i}`).trim();
          const name = String(row[1]).trim();
          const category = String(row[2] || 'عام').trim();
          const buyPrice = parseFloat(row[3]) || 0;
          const sellPrice = parseFloat(row[4]) || 0;
          const stock = parseInt(row[5]) || 0;
          const minStockAlert = parseInt(row[6]) || 5;

          importedProducts.push({
            id,
            name,
            category,
            buyPrice,
            sellPrice,
            stock,
            minStockAlert,
          });
        }

        resolve(importedProducts);
      } catch (err: any) {
        reject(err?.message || 'حدث خطأ أثناء تحليل ملف الإكسيل');
      }
    };
    reader.onerror = () => reject('فشل قراءة الملف كلياً');
    reader.readAsBinaryString(file);
  });
};
