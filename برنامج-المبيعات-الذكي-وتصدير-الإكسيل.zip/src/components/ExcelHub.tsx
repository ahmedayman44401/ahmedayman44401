import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { 
  FileSpreadsheet, 
  Download, 
  Upload, 
  Check, 
  AlertCircle, 
  Info,
  Phone,
  Layout,
  BookOpen
} from 'lucide-react';
import { Product, Sale } from '../types';
import { exportToExcel, importProductsFromExcel } from '../utils/excelUtils';

interface ExcelHubProps {
  products: Product[];
  sales: Sale[];
  onImportProducts: (imported: Product[]) => void;
}

export default function ExcelHub({ products, sales, onImportProducts }: ExcelHubProps) {
  const [importError, setImportError] = useState('');
  const [importSuccess, setImportSuccess] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleExport = () => {
    try {
      exportToExcel(products, sales);
    } catch (err) {
      alert('حدث خطأ أثناء تصدير شيت الإكسيل، يرجى المحاولة لاحقاً.');
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const processFile = async (file: File) => {
    setImportError('');
    setImportSuccess('');

    // Check file extension
    const extension = file.name.split('.').pop()?.toLowerCase();
    if (extension !== 'xlsx' && extension !== 'xls') {
      setImportError('عذراً، يجب اختيار ملف بصيغة إكسيل فقط (.xlsx أو .xls)');
      return;
    }

    try {
      const imported = await importProductsFromExcel(file);
      if (imported.length === 0) {
        setImportError('لم يتم العثور على أي منتجات صالحة داخل شيت المنتجات.');
        return;
      }

      onImportProducts(imported);
      setImportSuccess(`تهانينا! تم استيراد ودمج ${imported.length} منتجاً بنجاح في مخزنك.`);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err: any) {
      setImportError(err || 'فشل تحليل شيت الإكسيل. يرجى التأكد من تطابق الأعمدة مع النموذج.');
    }
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" id="excel-hub" dir="rtl">
      {/* Title */}
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-xl font-bold text-slate-900">بوابة تكامل ملفات الإكسيل (Excel)</h1>
        <p className="text-xs text-slate-500 mt-1">حمّل شيت المبيعات والمخزن المتكامل المفرغ أو المحفوظ للعمل عليه مباشرة على تطبيق Excel على جوالك</p>
      </div>

      {/* Grid: Export and Import Options */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Export Card */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="p-2 bg-slate-900 text-white rounded-md w-fit">
              <FileSpreadsheet size={18} />
            </div>
            <h2 className="text-sm font-bold text-slate-900">تصدير شيت إكسيل المتكامل للعمل على الموبايل</h2>
            <p className="text-xs text-slate-550 leading-relaxed">
              يقوم هذا الخيار بجمع كافة المنتجات بالمخازن وسجلات المبيعات النشطة، وبناء ملف إكسيل احترافي (.xlsx) متعدد الصفحات مع **معادلات حسابية ديناميكية نشطة**. 
              تستطيع تحميل هذا الملف وفتحه فوراً على هاتفك لتعديل الكميات ورؤية الأرباح تتغير تلقائياً في الإكسيل.
            </p>

            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-1.5 text-xs text-slate-600">
              <div className="font-bold text-slate-900 mb-1">الصفحات التي ستجدها داخل شيت الإكسيل:</div>
              <div className="flex items-center gap-1.5">• <b>الرئيسية (Dashboard):</b> تحليلات الأرباح ورأس المال المستثمر.</div>
              <div className="flex items-center gap-1.5">• <b>المنتجات:</b> قائمة السلع مع معادلة لحساب ربح القطعة تلقائياً.</div>
              <div className="flex items-center gap-1.5">• <b>المبيعات:</b> الفواتير مع حساب تلقائي للمبالغ الآجلة والمدفوعة.</div>
            </div>
          </div>

          <button 
            onClick={handleExport}
            className="w-full mt-4 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg transition-colors active:scale-98 text-xs flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download size={14} />
            <span>تحميل وتحديث شيت الإكسيل الجاهز للعمل (.xlsx)</span>
          </button>
        </div>

        {/* Import Card */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="p-2 bg-slate-900 text-white rounded-md w-fit">
              <Upload size={18} />
            </div>
            <h2 className="text-sm font-bold text-slate-900">استيراد المنتجات وقائمة المخزن من الإكسيل</h2>
            <p className="text-xs text-slate-550 leading-relaxed">
              هل تمتلك قائمة منتجات جاهزة في شيت إكسيل؟ بدلاً من كتابتها يدوياً، قم برفع ملف الإكسيل هنا، وسيقوم النظام تلقائياً بتحليل الأعمدة وتغذية مخزنك بالكامل بالأسعار والكميات في ثوانٍ معدودة.
            </p>

            {/* Drag and Drop Zone */}
            <div 
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-all ${
                isDragging 
                  ? 'border-slate-900 bg-slate-50' 
                  : 'border-slate-200 hover:border-slate-400 bg-slate-50/50 hover:bg-slate-50'
              }`}
            >
              <input 
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".xlsx, .xls"
                className="hidden"
              />
              <Upload size={20} className="mx-auto text-slate-400 mb-2" />
              <p className="text-xs font-bold text-slate-800">اسحب شيت الإكسيل هنا أو اضغط للتصفح</p>
              <p className="text-[10px] text-slate-400 mt-1">يدعم صيغ xlsx, xls فقط</p>
            </div>

            {/* Error & Success States */}
            {importError && (
              <div className="p-3 bg-rose-50 border border-rose-100 rounded-lg text-rose-700 text-xs font-semibold flex items-center gap-1.5">
                <AlertCircle size={14} className="shrink-0" />
                <span>{importError}</span>
              </div>
            )}
            {importSuccess && (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 text-xs font-semibold flex items-center gap-1.5 animate-fade-in">
                <Check size={14} className="shrink-0 text-slate-900" />
                <span>{importSuccess}</span>
              </div>
            )}
          </div>

          <div className="text-[10px] text-slate-400 mt-3 text-center flex items-center justify-center gap-1 bg-slate-50 p-2 rounded-lg border border-slate-200">
            <Info size={12} className="text-slate-400" />
            <span>ملاحظة: لنجاح الاستيراد، يرجى كتابة البيانات بدءاً من السطر الثاني في شيت مسمى "المنتجات".</span>
          </div>
        </div>

      </div>

      {/* Guide: How to run it on Excel for Mobile */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-4">
        <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
          <BookOpen size={15} className="text-slate-900" />
          <span>خطوات تشغيل برنامج المبيعات بكفاءة تامة على جوالك</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-600 leading-relaxed">
          {/* Step 1 */}
          <div className="space-y-2 p-4 bg-slate-50/50 rounded-lg border border-slate-200">
            <div className="w-6 h-6 rounded bg-slate-900 text-white font-bold flex items-center justify-center text-[10px]">١</div>
            <h3 className="font-bold text-slate-900 text-xs">تنزيل وتثبيت التطبيق على الموبايل</h3>
            <p className="text-slate-500 text-[11px]">
              قم بتحميل تطبيق <b>Microsoft Excel</b> الرسمي للـ Android أو الـ iPhone مجاناً من متجر التطبيقات لضمان دعم المعادلات العربية والتنسيقات.
            </p>
          </div>

          {/* Step 2 */}
          <div className="space-y-2 p-4 bg-slate-50/50 rounded-lg border border-slate-200">
            <div className="w-6 h-6 rounded bg-slate-900 text-white font-bold flex items-center justify-center text-[10px]">٢</div>
            <h3 className="font-bold text-slate-900 text-xs">تنزيل الملف المحسّن للموبايل</h3>
            <p className="text-slate-500 text-[11px]">
              اضغط على زر <b>"تحميل وتحديث شيت الإكسيل"</b> بالأعلى من متصفح هاتفك أو ارسله لنفسك عبر الواتساب وافتحه مباشرة داخل تطبيق إكسيل الموبايل.
            </p>
          </div>

          {/* Step 3 */}
          <div className="space-y-2 p-4 bg-slate-50/50 rounded-lg border border-slate-200">
            <div className="w-6 h-6 rounded bg-slate-900 text-white font-bold flex items-center justify-center text-[10px]">٣</div>
            <h3 className="font-bold text-slate-900 text-xs">الاستخدام والمزامنة العكسية</h3>
            <p className="text-slate-500 text-[11px]">
              عند إدخال مبيعات جديدة داخل الشيت على الجوال، ستقوم معادلات الإكسيل تلقائياً بتحديث اللوحة الرئيسية والربح الإجمالي. كما يمكنك لاحقاً إعادة رفع شيت "المنتجات" هنا لتحديث المخزن السحابي.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
